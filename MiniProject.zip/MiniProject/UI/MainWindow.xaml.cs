﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
           
        }
        public void clear()
        {
            lbltitle.Visibility = Visibility.Hidden;
            lbltypeofprocess.Visibility = Visibility.Hidden;
            img.Visibility = Visibility.Hidden;
            btnjobseeker.Visibility = Visibility.Hidden;
            btnEmployer.Visibility = Visibility.Hidden;
        }
        public void clear1()
        {

            lbltitle.Visibility = Visibility.Visible;
            lbltypeofprocess.Visibility = Visibility.Visible;
            img.Visibility = Visibility.Visible;
            btnjobseeker.Visibility = Visibility.Visible;
            btnEmployer.Visibility = Visibility.Visible;
            btnlogin.Visibility = Visibility.Hidden;
            btnregister.Visibility = Visibility.Hidden;
            lbluserid.Visibility = Visibility.Hidden;
            txtuserid.Visibility = Visibility.Hidden;
            lblpassword.Visibility = Visibility.Hidden;
            txtpassword.Visibility = Visibility.Hidden;
            btnsubmit.Visibility = Visibility.Hidden;
            btncancel.Visibility = Visibility.Hidden;
            btnhome.Visibility = Visibility.Hidden;
        }
        private void BtnEmployer_Click(object sender, RoutedEventArgs e)
        {
            btnlogin.Visibility = (Visibility).1;
            btnregister.Visibility = (Visibility).1;
            btnhome.Visibility = (Visibility).1;
            clear();
           
        }

        private void Btnjobseeker_Click(object sender, RoutedEventArgs e)
        {
            btnlogin.Visibility = (Visibility).1;
            btnregister.Visibility = (Visibility).1;
            btnhome.Visibility = (Visibility).1;
            clear();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            lbltitle.Visibility = (Visibility).1;
            lbltypeofprocess.Visibility = (Visibility).1;
            btnEmployer.Visibility = (Visibility).1;
            btnjobseeker.Visibility = (Visibility).1;
            img.Visibility = (Visibility).1;
            lblc2.Visibility = Visibility.Visible;
            gridrjobregister.Visibility = Visibility.Hidden;
        }

        private void Btnlogin_Click(object sender, RoutedEventArgs e)
        {
            lbluserid.Visibility = Visibility.Visible;
            txtuserid.Visibility = Visibility.Visible;
            lblpassword.Visibility = Visibility.Visible;
            txtpassword.Visibility = Visibility.Visible;
            btnsubmit.Visibility = Visibility.Visible;
            btncancel.Visibility = Visibility.Visible;
            btnhome.Visibility = Visibility.Visible;
            btnlogin.Visibility = Visibility.Hidden;
            btnregister.Visibility = Visibility.Hidden;
        }

        private void Btnregister_Click(object sender, RoutedEventArgs e)
        {
            if (btnjobseeker.IsEnabled==true)
            {
             gridrjobregister.Visibility = Visibility.Visible;
            }
           
        }

        private void Btnsubmit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Btncancel_Click(object sender, RoutedEventArgs e)
        {
            btnlogin.Visibility = Visibility.Visible;
            btnregister.Visibility = Visibility.Visible;
            btnhome.Visibility = Visibility.Visible;
      
            btnlogin.Visibility = Visibility.Visible;
            btnregister.Visibility = Visibility.Visible;
            lbluserid.Visibility = Visibility.Hidden;
            txtuserid.Visibility = Visibility.Hidden;
            lblpassword.Visibility = Visibility.Hidden;
            txtpassword.Visibility = Visibility.Hidden;
            btnsubmit.Visibility = Visibility.Hidden;
            btncancel.Visibility = Visibility.Hidden;
        }

        private void Btnhome_Click(object sender, RoutedEventArgs e)
        {
            clear1();
        }
    }
}
